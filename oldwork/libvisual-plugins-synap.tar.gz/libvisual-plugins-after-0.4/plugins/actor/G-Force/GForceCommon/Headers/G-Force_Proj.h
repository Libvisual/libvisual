

#include "EgCommon.h"




#define GFORCE	1




#define MAX_WAVES_PER_SHAPE  15

#define GFORCE_COMPAT_VERSION 116
#define GFORCE_VERS_STR "Welcome to G-Force 1.1.6"

#define cGForceID		'g4ce'
#define cPluginAuthor	'Av55'

