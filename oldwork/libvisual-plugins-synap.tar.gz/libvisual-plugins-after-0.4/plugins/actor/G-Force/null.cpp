// This file (null.cpp) is here because automake screws up if there is
// no source file here.  This file also forces the use of the c++ compiler
// for the final linking.  That may be a good thing because we have c++ code.

int pointless = 0xdead;

