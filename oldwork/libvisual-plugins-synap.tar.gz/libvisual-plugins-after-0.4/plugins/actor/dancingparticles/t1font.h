// load Centers with a form that corresponds to str

void loadString(char *str);

