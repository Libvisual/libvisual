#ifndef __DANCINGPARTICLES_GL_H
#define __DANCINGPARTICLES_GL_H

void init_gl(void);
void draw_gl(void);
void init_surface(void);

#endif
