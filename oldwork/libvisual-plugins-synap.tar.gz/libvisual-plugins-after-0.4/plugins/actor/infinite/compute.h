#ifndef _INF_COMPUTE_H
#define _INF_COMPUTE_H

#define NB_FCT 7

void _inf_generate_vector_field(InfinitePrivate *priv, t_interpol* vector_field);

#endif /* _INF_COMPUTE_H */
